enum_class_header = "class {class_name}(Enum):"
